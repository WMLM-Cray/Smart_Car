#!/bin/bash

# 使用 $HOME 自动匹配当前用户的根目录 (也就是 /home/orange-pi)
MAP_DIR="$HOME/racecar/src/racecar/map"
MAP_NAME="map1"
# MAP_NAME="ai_map"

mkdir -p "$MAP_DIR"

# 运行 map_saver_cli 命令保存地图
ros2 run nav2_map_server map_saver_cli -f "$MAP_DIR/$MAP_NAME"