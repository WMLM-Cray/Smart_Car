#!/usr/bin/env python3
import rclpy
from rclpy.action import ActionClient
from rclpy.node import Node
from nav2_msgs.action import NavigateThroughPoses
from geometry_msgs.msg import PoseStamped, Twist
from std_msgs.msg import Bool
import csv
import time

class NavThroughPosesClient(Node):
    def __init__(self):
        super().__init__('nav_through_poses_client')
        self._action_client = ActionClient(self, NavigateThroughPoses, 'navigate_through_poses')
        self.cmd_vel_sub = self.create_subscription(Twist, '/cmd_vel', self.cmd_vel_callback, 10)
        self.car_cmd_vel_pub = self.create_publisher(Twist, '/car_cmd_vel', 10)
        self.detection_sub = self.create_subscription(Bool, '/detection_result', self.detection_callback, 10)
        
        self.distance_remaining = None
        self.is_paused = False
        self.cooldown = False
        self.cooldown_start = 0

    def send_goal(self, poses):
        goal_msg = NavigateThroughPoses.Goal()
        goal_msg.poses = poses
        self._action_client.wait_for_server(timeout_sec=10.0)
        self._send_goal_future = self._action_client.send_goal_async(
            goal_msg, feedback_callback=self.feedback_callback
        )
        self._send_goal_future.add_done_callback(self.goal_response_callback)

    def goal_response_callback(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().info('Goal rejected :(')
            return
        self.get_logger().info('Goal accepted :)')
        self._get_result_future = goal_handle.get_result_async()
        self._get_result_future.add_done_callback(self.get_result_callback)

    def get_result_callback(self, future):
        result = future.result().result
        self.get_logger().info('Navigation result: {0}'.format(result))

    def feedback_callback(self, feedback_msg):
        feedback = feedback_msg.feedback
        if feedback.distance_remaining > 0.0:
            self.get_logger().info(f'Distance to target: {feedback.distance_remaining:.2f} meters')
            self.distance_remaining = feedback.distance_remaining

    def cmd_vel_callback(self, msg):
        # ★ 距离过滤（来自 go.py）+ 检测暂停（原有功能）
        if self.distance_remaining is not None and self.distance_remaining < 0.5:
            return   # 靠近路径点时不转发，让车自然停住
        if self.is_paused:
            return   # 检测到斑马线/红绿灯时暂停
        self.car_cmd_vel_pub.publish(msg)

    def detection_callback(self, msg):
        if msg.data and not self.cooldown:
            self.get_logger().info('Detection result received, stopping the robot.')
            self.is_paused = True
            self.cooldown = True
            self.cooldown_start = time.time()
            twist = Twist()
            twist.linear.x = 0.0
            twist.angular.z = 0.0
            self.car_cmd_vel_pub.publish(twist)
            self.timer = self.create_timer(3.0, self.resume_navigation)

    def resume_navigation(self):
        self.is_paused = False
        self.cooldown = False
        self.get_logger().info('Resuming navigation after cooldown period.')
        self.timer.cancel()


def read_waypoints_from_csv(filename):
    waypoints = []
    with open(filename, 'r') as f:
        reader = csv.reader(f)
        for row in reader:
            if len(row) == 4:
                waypoints.append({
                    "x": float(row[0]),
                    "y": float(row[1]),
                    "z": float(row[2]),
                    "w": float(row[3])
                })
    return waypoints


def main(args=None):
    rclpy.init(args=args)
    client = NavThroughPosesClient()

    waypoints = read_waypoints_from_csv(
        '/home/davinci-mini/racecar/src/racecar/scripts/ai_test1.csv'
    )
    poses = []
    for point in waypoints:
        pose = PoseStamped()
        pose.header.frame_id = 'map'
        pose.header.stamp.sec = 0
        pose.pose.position.x = point["x"]
        pose.pose.position.y = point["y"]
        pose.pose.position.z = point["z"]
        pose.pose.orientation.w = point["w"]
        poses.append(pose)

    client.send_goal(poses)

    try:
        rclpy.spin(client)
    except KeyboardInterrupt:
        pass
    finally:
        # ★ 退出前发送零速度
        twist = Twist()
        client.car_cmd_vel_pub.publish(twist)
        client.destroy_node()
        rclpy.shutdown()



if __name__ == '__main__':
    main()
