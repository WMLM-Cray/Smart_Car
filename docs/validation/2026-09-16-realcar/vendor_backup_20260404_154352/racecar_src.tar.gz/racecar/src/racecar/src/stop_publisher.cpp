#include "rclcpp/rclcpp.hpp"
#include "geometry_msgs/msg/twist.hpp"

using namespace std::chrono_literals;

class StopPublisher : public rclcpp::Node
{
public:
    StopPublisher() : Node("stop")
    {
        // 创建发布者，话题名 '/car/cmd_vel'，队列大小 10
        publisher_ = this->create_publisher<geometry_msgs::msg::Twist>("/car/cmd_vel", 10);

        // 设置定时器，每 100ms（即 10Hz）触发一次回调
        timer_ = this->create_wall_timer(100ms, std::bind(&StopPublisher::timer_callback, this));

        RCLCPP_INFO(this->get_logger(), "🛑 [stop] 节点启动 —— 正在发送停止指令...");
    }

private:
    void timer_callback()
    {
        auto message = geometry_msgs::msg::Twist();
        message.linear.x = 0.0;   // 停止前进/后退
        message.angular.z = 0.0;  // 停止转向

        publisher_->publish(message);
        RCLCPP_DEBUG(this->get_logger(), "已发布停止指令: linear.x=%.2f, angular.z=%.2f",
                     message.linear.x, message.angular.z);
    }

    rclcpp::TimerBase::SharedPtr timer_;
    rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr publisher_;
};

int main(int argc, char * argv[])
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<StopPublisher>();

    try {
        rclcpp::spin(node);
    } catch (const std::exception & e) {
        RCLCPP_ERROR(rclcpp::get_logger("stop"), "异常: %s", e.what());
    }

    rclcpp::shutdown();
    return 0;
}
