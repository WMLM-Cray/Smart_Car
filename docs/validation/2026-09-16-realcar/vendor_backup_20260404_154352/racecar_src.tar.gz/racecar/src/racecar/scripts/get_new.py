#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped
import sys, select, termios, tty
import csv
import os
import time

class GoalPoseSubscriber(Node):
    def __init__(self):
        super().__init__('get_point')
        
        # Create subscription
        self.subscription = self.create_subscription(
            PoseStamped,
            '/goal_pose',
            self.pose_stamped_cb,
            10)
        
        self.points = []
        self.settings = None
        self.fd = sys.stdin.fileno()
        
        # Save terminal settings for restoration
        try:
            self.settings = termios.tcgetattr(self.fd)
        except termios.error:
            self.get_logger().warn("Failed to get terminal settings. Key input disabled.")
            self.settings = None

    def pose_stamped_cb(self, msg):
        # Extract position (x, y) and orientation (z, w)
        gx = msg.pose.position.x
        gy = msg.pose.position.y
        gz = msg.pose.orientation.z 
        gw = msg.pose.orientation.w 
        
        point_data = [gx, gy, gz, gw]
        self.points.append(point_data)
        self.get_logger().info(f"New point received: {point_data} (Total: {len(self.points)})")

    def get_key(self):
        if self.settings is None:
            return ''
        
        try:
            tty.setraw(self.fd)
            rlist, _, _ = select.select([sys.stdin], [], [], 0.05)
            if rlist:
                key = sys.stdin.read(1)
            else:
                key = ''
        finally:
            # Ensure terminal settings are restored
            termios.tcsetattr(self.fd, termios.TCSADRAIN, self.settings)
        
        return key

    def data_write_csv(self, file_name, datas):
        if not datas:
            self.get_logger().warn("No data to save! List is empty.")
            return

        try:
            # Ensure directory exists
            dir_name = os.path.dirname(file_name)
            if dir_name and not os.path.exists(dir_name):
                os.makedirs(dir_name)
                self.get_logger().info(f"Created directory: {dir_name}")

            with open(file_name, 'w', newline='', encoding='utf-8') as file_csv:
                writer = csv.writer(file_csv, delimiter=',', quoting=csv.QUOTE_MINIMAL)
                # Write header
                writer.writerow(['pos_x', 'pos_y', 'orient_z', 'orient_w']) 
                for data in datas:
                    writer.writerow(data)
            
            self.get_logger().info(f'Successfully saved {len(datas)} points to: {file_name}')
            
        except PermissionError:
            self.get_logger().error(f"Permission Error: Cannot write to {file_name}")
        except FileNotFoundError:
            self.get_logger().error(f"Path Error: Directory does not exist and cannot be created: {file_name}")
        except Exception as e:
            self.get_logger().error(f"Save failed: {str(e)}")

def main(args=None):
    rclpy.init(args=args)
    node = GoalPoseSubscriber()

    # Determine path: current script directory
    script_dir = os.path.dirname(os.path.abspath(__file__))
    default_file_path = os.path.join(script_dir, 'out_test.csv')
    
    target_path = default_file_path 

    node.get_logger().info("Node started. Press 'f' to save CSV, 'Ctrl+C' to exit.")
    node.get_logger().info(f"Target save path: {target_path}")

    try:
        while rclpy.ok():
            # Process callbacks
            rclpy.spin_once(node, timeout_sec=0.05)
            
            # Process key input
            key = node.get_key()
            
            if key == 'f' or key == 'F':
                node.data_write_csv(target_path, node.points)
            elif key == '\x03':  # Ctrl+C
                break
            elif key != '':
                node.get_logger().info(f"Key detected: '{key}' (Only 'f' is valid)")
                
    except KeyboardInterrupt:
        pass
    finally:
        # Ensure terminal state is restored
        if node.settings:
            termios.tcsetattr(sys.stdin.fileno(), termios.TCSADRAIN, node.settings)
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()