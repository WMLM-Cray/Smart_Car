#!/usr/bin/env python3

import rclpy
from rclpy.action import ActionClient
from rclpy.node import Node
from nav2_msgs.action import NavigateThroughPoses
from geometry_msgs.msg import PoseStamped, Twist
from std_msgs.msg import String
import configparser
import csv
import os
import time

CONFIG_PATH = '/home/orange-pi/racecar/src/racecar/scripts/go_params.ini'

DEFAULT_CONFIG = {
    'stop_waypoints': {5, 8, 10},
    'stop_duration_sec': 3.0,
    'permanent_stop_waypoints': {29},
    'stop_linear_x': 0.0,
    'stop_angular_z': 0.0,
}

def parse_waypoints(value):
    if not value.strip():
        return set()
    return {int(item.strip()) for item in value.split(',') if item.strip()}

def load_go_config(path):
    config = DEFAULT_CONFIG.copy()
    if not os.path.exists(path):
        return config

    parser = configparser.ConfigParser()
    parser.read(path, encoding='utf-8')
    if not parser.has_section('navigation'):
        return config

    section = parser['navigation']
    if 'stop_waypoints' in section:
        config['stop_waypoints'] = parse_waypoints(section.get('stop_waypoints', ''))
    if 'stop_duration_sec' in section:
        config['stop_duration_sec'] = section.getfloat('stop_duration_sec')
    if 'permanent_stop_waypoints' in section:
        config['permanent_stop_waypoints'] = parse_waypoints(section.get('permanent_stop_waypoints', ''))
    if 'stop_linear_x' in section:
        config['stop_linear_x'] = section.getfloat('stop_linear_x')
    if 'stop_angular_z' in section:
        config['stop_angular_z'] = section.getfloat('stop_angular_z')
    return config

class NavThroughPosesClient(Node):
    def __init__(self):
        super().__init__('nav_through_poses_client')
        self.config = load_go_config(CONFIG_PATH)
        self._action_client = ActionClient(self, NavigateThroughPoses, 'navigate_through_poses')
        self.cmd_vel_sub = self.create_subscription(Twist, '/cmd_vel', self.cmd_vel_callback, 10)
        self.light_sub = self.create_subscription(String, '/light', self.light_callback, 10)
        self.car_cmd_vel_pub = self.create_publisher(Twist, '/car_cmd_vel', 10)
        self.stop_timer = self.create_timer(0.1, self.stop_timer_callback)
        self.distance_remaining = None
        self.is_paused = False  # 标志位，用于控制是否暂停导航
        self.traffic_paused = False  # 红灯停车，绿灯恢复
        self.waypoint_paused = False  # 到指定导航点后定点停车
        self.permanent_paused = False  # 到永久停车点后不再恢复
        self.waypoint_resume_time = 0.0
        self.total_waypoints = 0
        self.stopped_waypoints = set()
        self.cycle_number=0
        self.fin_flag=False
        self.get_logger().info(f'Loaded navigation params from {CONFIG_PATH}: {self.config}')

    def send_goal(self, poses):
        self.total_waypoints = len(poses)
        goal_msg = NavigateThroughPoses.Goal()
        goal_msg.poses = poses

        self._action_client.wait_for_server(timeout_sec=10.0)
        self._send_goal_future = self._action_client.send_goal_async(goal_msg, feedback_callback=self.feedback_callback)
        self._send_goal_future.add_done_callback(self.goal_response_callback)

    def goal_response_callback(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().info('Goal rejected :(')
            return

        self.get_logger().info('Goal accepted :)')

        self._get_result_future = goal_handle.get_result_async()
        self._get_result_future.add_done_callback(self.get_result_callback)

    def get_result_callback(self, future):
        result = future.result().result
        self.get_logger().info('Navigation result: {0}'.format(result))
        # rclpy.shutdown()

    def feedback_callback(self, feedback_msg):
        feedback = feedback_msg.feedback
        if  feedback.distance_remaining > 0.0:
            self.get_logger().info(f'Distance to target: {feedback.distance_remaining:.2f} meters')
            self.distance_remaining = feedback.distance_remaining
            self.check_waypoint_stop(feedback)
            # 如果距离目标点的距离小于 0.3米，发送停止命令
            if self.distance_remaining is not None and feedback.distance_remaining < 0.3 and not self.is_paused:


                self.get_logger().info('Reached the target, stopping the robot.')
                self.is_paused = True  # 设置标志位为暂停状态
                twist = Twist()
                twist.linear.x = 0.0
                twist.angular.z = 0.0
                self.car_cmd_vel_pub.publish(twist)


    def cmd_vel_callback(self, msg):

        # if  self.distance_remaining > 0.5 and not self.is_paused:
        if self.distance_remaining is not None and self.distance_remaining > 0.5 and not self.is_paused and not self.traffic_paused and not self.waypoint_paused and not self.permanent_paused:
            # 否则，正常转发速度命令
            self.car_cmd_vel_pub.publish(msg)

    def check_waypoint_stop(self, feedback):
        if self.total_waypoints <= 0:
            return

        remaining = getattr(feedback, 'number_of_poses_remaining', None)
        if remaining is None:
            return

        reached_index = self.total_waypoints - remaining
        if reached_index in self.config['permanent_stop_waypoints'] and reached_index not in self.stopped_waypoints:
            self.stopped_waypoints.add(reached_index)
            self.permanent_paused = True
            self.waypoint_paused = False
            self.get_logger().info(f'Reached waypoint {reached_index}, stopping permanently.')
            self.publish_stop()
            return

        if reached_index in self.config['stop_waypoints'] and reached_index not in self.stopped_waypoints:
            self.stopped_waypoints.add(reached_index)
            self.waypoint_paused = True
            self.waypoint_resume_time = time.monotonic() + self.config['stop_duration_sec']
            self.get_logger().info(
                f"Reached waypoint {reached_index}, stopping for {self.config['stop_duration_sec']:.1f} seconds."
            )
            self.publish_stop()

    def light_callback(self, msg):
        light = msg.data.strip().lower()
        if light == 'red':
            if not self.traffic_paused:
                self.get_logger().info('Red light detected, stopping navigation.')
            self.traffic_paused = True
            self.publish_stop()
        elif light == 'green':
            if self.traffic_paused:
                self.get_logger().info('Green light detected, resuming navigation.')
            self.traffic_paused = False

    def stop_timer_callback(self):
        if self.waypoint_paused and time.monotonic() >= self.waypoint_resume_time:
            self.waypoint_paused = False
            self.get_logger().info('Waypoint stop finished, resuming navigation.')

        if self.traffic_paused or self.waypoint_paused or self.permanent_paused:
            self.publish_stop()

    def publish_stop(self):
        twist = Twist()
        twist.linear.x = self.config['stop_linear_x']
        twist.angular.z = self.config['stop_angular_z']
        self.car_cmd_vel_pub.publish(twist)


def read_waypoints_from_csv(filename):
    waypoints = []
    with open(filename, 'r') as f:
        reader = csv.reader(f)
        for row in reader:
            if len(row) == 4:  # Ensure each row has x, y, z, w
                waypoints.append({
                    "x": float(row[0]),
                    "y": float(row[1]),
                    "z": float(row[2]),
                    "w": float(row[3])
                })
    return waypoints

def main(args=None):
    rclpy.init(args=args)

    client = NavThroughPosesClient()

    # 从CSV文件读取导航点
    waypoints = read_waypoints_from_csv('/home/orange-pi/racecar/src/racecar/scripts/ai_test1.csv')
    # waypoints = read_waypoints_from_csv('/home/davinci-mini/racecar/src/racecar/scripts/out_test.csv')


    # 将导航点转换为 PoseStamped 消息
    poses = []
    for point in waypoints:
        pose = PoseStamped()
        pose.header.frame_id = 'map'
        pose.header.stamp.sec = 0
        pose.pose.position.x = point["x"]
        pose.pose.position.y = point["y"]
        pose.pose.position.z = point["z"]
        pose.pose.orientation.w = point["w"]
        poses.append(pose)

    client.send_goal(poses)

    rclpy.spin(client)

if __name__ == '__main__':
    main()
