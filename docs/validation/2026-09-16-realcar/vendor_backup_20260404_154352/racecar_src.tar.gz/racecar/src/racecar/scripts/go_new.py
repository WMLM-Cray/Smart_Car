#!/usr/bin/env python3

import rclpy
from rclpy.action import ActionClient
from rclpy.node import Node
from nav2_msgs.action import NavigateThroughPoses
from geometry_msgs.msg import PoseStamped, Twist
import csv
import os
import sys


class NavThroughPosesClient(Node):
    def __init__(self, csv_path, goal_tolerance=0.5, goal_count=None):
        super().__init__('nav_through_poses_client')
        self._action_client = ActionClient(self, NavigateThroughPoses, 'navigate_through_poses')
        self.cmd_vel_sub = self.create_subscription(Twist, '/cmd_vel', self.cmd_vel_callback, 10)
        self.car_cmd_vel_pub = self.create_publisher(Twist, '/car_cmd_vel', 10)
        self.distance_remaining = None
        self.is_paused = False
        self.goal_tolerance = goal_tolerance
        self.goal_count = goal_count
        self.poses = []
        self.csv_path = csv_path

    def send_goal(self, poses):
        goal_msg = NavigateThroughPoses.Goal()
        goal_msg.poses = poses
        self._action_client.wait_for_server(timeout_sec=10.0)
        self._send_goal_future = self._action_client.send_goal_async(
            goal_msg, feedback_callback=self.feedback_callback)
        self._send_goal_future.add_done_callback(self.goal_response_callback)

    def goal_response_callback(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().error('目标被拒绝')
            return
        self.get_logger().info('目标已接受')
        self._get_result_future = goal_handle.get_result_async()
        self._get_result_future.add_done_callback(self.get_result_callback)

    def get_result_callback(self, future):
        result = future.result().result
        self.get_logger().info(f'导航结果: {result}')

    def feedback_callback(self, feedback_msg):
        feedback = feedback_msg.feedback
        if feedback.distance_remaining > 0.0:
            self.distance_remaining = feedback.distance_remaining
            self.get_logger().info(f'剩余距离: {feedback.distance_remaining:.2f} m')
            if feedback.distance_remaining < self.goal_tolerance and not self.is_paused:
                self.get_logger().info('到达目标，停车')
                self.is_paused = True
                self._publish_stop()

    def cmd_vel_callback(self, msg):
        if self.is_paused or self.distance_remaining is None:
            return
        if self.distance_remaining > self.goal_tolerance:
            self.car_cmd_vel_pub.publish(msg)

    def _publish_stop(self):
        twist = Twist()
        self.car_cmd_vel_pub.publish(twist)

    def run(self):
        if not self._load_and_send():
            return
        rclpy.spin(self)

    def _load_and_send(self):
        waypoints = self._read_waypoints()
        if not waypoints:
            self.get_logger().error('无有效路径点，退出')
            return False

        if self.goal_count is not None:
            waypoints = waypoints[:self.goal_count]
            self.get_logger().info(f'使用前 {len(waypoints)} 个路径点')

        poses = self._waypoints_to_poses(waypoints)
        self.get_logger().info(f'共 {len(poses)} 个路径点，开始导航')
        self.send_goal(poses)
        return True

    def _read_waypoints(self):
        if not os.path.exists(self.csv_path):
            self.get_logger().error(f'CSV 文件不存在: {self.csv_path}')
            return []

        waypoints = []
        with open(self.csv_path, 'r') as f:
            reader = csv.reader(f)
            for i, row in enumerate(reader):
                if len(row) != 4:
                    self.get_logger().warn(f'第 {i+1} 行格式错误，跳过: {row}')
                    continue
                try:
                    waypoints.append({
                        "x": float(row[0]),
                        "y": float(row[1]),
                        "z": float(row[2]),
                        "w": float(row[3])
                    })
                except ValueError:
                    self.get_logger().warn(f'第 {i+1} 行数值解析失败，跳过: {row}')
        return waypoints

    def _waypoints_to_poses(self, waypoints):
        poses = []
        for point in waypoints:
            pose = PoseStamped()
            pose.header.frame_id = 'map'
            pose.header.stamp.sec = 0
            pose.pose.position.x = point["x"]
            pose.pose.position.y = point["y"]
            pose.pose.position.z = point["z"]
            pose.pose.orientation.w = point["w"]
            poses.append(pose)
        return poses


def main(args=None):
    rclpy.init(args=args)

    # 默认路径，可通过命令行参数覆盖
    default_csv = os.path.join(os.path.dirname(__file__), 'ai_test1.csv')
    csv_path = sys.argv[1] if len(sys.argv) > 1 else default_csv
    goal_tolerance = float(sys.argv[2]) if len(sys.argv) > 2 else 0.5
    goal_count = int(sys.argv[3]) if len(sys.argv) > 3 else None

    client = NavThroughPosesClient(csv_path, goal_tolerance, goal_count)

    try:
        client.run()
    except KeyboardInterrupt:
        client.get_logger().info('用户中断')
    finally:
        client._publish_stop()
        client.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
