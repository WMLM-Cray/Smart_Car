// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef LSLIDAR_MSGS__SRV__TAIL_REMOVAL_HPP_
#define LSLIDAR_MSGS__SRV__TAIL_REMOVAL_HPP_

#include "lslidar_msgs/srv/detail/tail_removal__struct.hpp"
#include "lslidar_msgs/srv/detail/tail_removal__builder.hpp"
#include "lslidar_msgs/srv/detail/tail_removal__traits.hpp"
#include "lslidar_msgs/srv/detail/tail_removal__type_support.hpp"

#endif  // LSLIDAR_MSGS__SRV__TAIL_REMOVAL_HPP_
